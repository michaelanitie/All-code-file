﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ExitBtn = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.BMI = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.BMITextBox = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ResultTxt = New System.Windows.Forms.TextBox()
        Me.CloseRBtn = New System.Windows.Forms.RadioButton()
        Me.WeightUnitLbl = New System.Windows.Forms.Label()
        Me.HeightUnitLbl = New System.Windows.Forms.Label()
        Me.lblUserType = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AgeTxt = New System.Windows.Forms.TextBox()
        Me.MetricRBtn = New System.Windows.Forms.RadioButton()
        Me.HeightTxt = New System.Windows.Forms.TextBox()
        Me.WeightTxt = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ClearBtn = New System.Windows.Forms.Button()
        Me.CalculateBtn = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.BMITextBox1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ResultTxt1 = New System.Windows.Forms.TextBox()
        Me.CloseRBtn1 = New System.Windows.Forms.RadioButton()
        Me.WeightUnitLbl1 = New System.Windows.Forms.Label()
        Me.HeightUnitLbl1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.AgeTxt1 = New System.Windows.Forms.TextBox()
        Me.HeightTxt1 = New System.Windows.Forms.TextBox()
        Me.ImperialRBtn1 = New System.Windows.Forms.RadioButton()
        Me.WeightTxt1 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.ClearBtn1 = New System.Windows.Forms.Button()
        Me.CalculateBtn1 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BMIAnalysisBtn = New System.Windows.Forms.Button()
        Me.BMRAnalysisBtn = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BMR = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.CR = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.BMRTextBox = New System.Windows.Forms.TextBox()
        Me.RadioBtn5 = New System.Windows.Forms.RadioButton()
        Me.RadioBtn4 = New System.Windows.Forms.RadioButton()
        Me.RadioBtn3 = New System.Windows.Forms.RadioButton()
        Me.RadioBtn1 = New System.Windows.Forms.RadioButton()
        Me.RadioBtn2 = New System.Windows.Forms.RadioButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.AgeBmrTxt = New System.Windows.Forms.TextBox()
        Me.HeightBmrTxt = New System.Windows.Forms.TextBox()
        Me.WeightBmrTxt = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.btnCalculateBMRClear = New System.Windows.Forms.Button()
        Me.btnCalculateBMR = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.CR2 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.BMRTextBox2 = New System.Windows.Forms.TextBox()
        Me.RadioBtn52 = New System.Windows.Forms.RadioButton()
        Me.RadioBtn42 = New System.Windows.Forms.RadioButton()
        Me.RadioBtn32 = New System.Windows.Forms.RadioButton()
        Me.RadioBtn12 = New System.Windows.Forms.RadioButton()
        Me.RadioBtn22 = New System.Windows.Forms.RadioButton()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.AgeBmrTxt2 = New System.Windows.Forms.TextBox()
        Me.HeightBmrTxt2 = New System.Windows.Forms.TextBox()
        Me.WeightBmrTxt2 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.btnCalculateBMRClear2 = New System.Windows.Forms.Button()
        Me.btnCalculateBMR2 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BMI.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.BMR.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ExitBtn
        '
        Me.ExitBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExitBtn.ForeColor = System.Drawing.Color.Black
        Me.ExitBtn.Location = New System.Drawing.Point(894, 601)
        Me.ExitBtn.Name = "ExitBtn"
        Me.ExitBtn.Size = New System.Drawing.Size(121, 52)
        Me.ExitBtn.TabIndex = 13
        Me.ExitBtn.Text = "Exit"
        Me.ExitBtn.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.OldLace
        Me.Button4.ForeColor = System.Drawing.Color.Black
        Me.Button4.Location = New System.Drawing.Point(36, 204)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(154, 68)
        Me.Button4.TabIndex = 14
        Me.Button4.Text = "About Us"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'BMI
        '
        Me.BMI.Controls.Add(Me.TabPage1)
        Me.BMI.Controls.Add(Me.TabPage2)
        Me.BMI.Location = New System.Drawing.Point(0, 0)
        Me.BMI.Name = "BMI"
        Me.BMI.SelectedIndex = 0
        Me.BMI.Size = New System.Drawing.Size(671, 506)
        Me.BMI.TabIndex = 23
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.OldLace
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.BMITextBox)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.ResultTxt)
        Me.TabPage1.Controls.Add(Me.CloseRBtn)
        Me.TabPage1.Controls.Add(Me.WeightUnitLbl)
        Me.TabPage1.Controls.Add(Me.HeightUnitLbl)
        Me.TabPage1.Controls.Add(Me.lblUserType)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.AgeTxt)
        Me.TabPage1.Controls.Add(Me.MetricRBtn)
        Me.TabPage1.Controls.Add(Me.HeightTxt)
        Me.TabPage1.Controls.Add(Me.WeightTxt)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.ClearBtn)
        Me.TabPage1.Controls.Add(Me.CalculateBtn)
        Me.TabPage1.ForeColor = System.Drawing.Color.Black
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(663, 473)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "METRIC BMI CALCULATOR "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(20, 33)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(343, 32)
        Me.Label10.TabIndex = 50
        Me.Label10.Text = "Body Mass Index: MALE"
        '
        'BMITextBox
        '
        Me.BMITextBox.Location = New System.Drawing.Point(414, 271)
        Me.BMITextBox.Multiline = True
        Me.BMITextBox.Name = "BMITextBox"
        Me.BMITextBox.Size = New System.Drawing.Size(167, 40)
        Me.BMITextBox.TabIndex = 49
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(22, 291)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 20)
        Me.Label7.TabIndex = 48
        Me.Label7.Text = "Result"
        '
        'ResultTxt
        '
        Me.ResultTxt.Location = New System.Drawing.Point(218, 271)
        Me.ResultTxt.Multiline = True
        Me.ResultTxt.Name = "ResultTxt"
        Me.ResultTxt.Size = New System.Drawing.Size(167, 40)
        Me.ResultTxt.TabIndex = 47
        '
        'CloseRBtn
        '
        Me.CloseRBtn.AutoSize = True
        Me.CloseRBtn.Checked = True
        Me.CloseRBtn.Location = New System.Drawing.Point(455, 122)
        Me.CloseRBtn.Name = "CloseRBtn"
        Me.CloseRBtn.Size = New System.Drawing.Size(74, 24)
        Me.CloseRBtn.TabIndex = 46
        Me.CloseRBtn.TabStop = True
        Me.CloseRBtn.Text = "Close"
        Me.CloseRBtn.UseVisualStyleBackColor = True
        '
        'WeightUnitLbl
        '
        Me.WeightUnitLbl.AutoSize = True
        Me.WeightUnitLbl.Location = New System.Drawing.Point(384, 358)
        Me.WeightUnitLbl.Name = "WeightUnitLbl"
        Me.WeightUnitLbl.Size = New System.Drawing.Size(21, 20)
        Me.WeightUnitLbl.TabIndex = 45
        Me.WeightUnitLbl.Text = "..."
        '
        'HeightUnitLbl
        '
        Me.HeightUnitLbl.AutoSize = True
        Me.HeightUnitLbl.Location = New System.Drawing.Point(384, 390)
        Me.HeightUnitLbl.Name = "HeightUnitLbl"
        Me.HeightUnitLbl.Size = New System.Drawing.Size(21, 20)
        Me.HeightUnitLbl.TabIndex = 44
        Me.HeightUnitLbl.Text = "..."
        '
        'lblUserType
        '
        Me.lblUserType.AutoSize = True
        Me.lblUserType.Location = New System.Drawing.Point(22, 122)
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.Size = New System.Drawing.Size(44, 20)
        Me.lblUserType.TabIndex = 31
        Me.lblUserType.Text = "AGE"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(22, 174)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(152, 20)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "HEIGHT (E.G. 183):"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 231)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(142, 20)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "WEIGHT (E.G 63):"
        '
        'AgeTxt
        '
        Me.AgeTxt.Location = New System.Drawing.Point(218, 102)
        Me.AgeTxt.Multiline = True
        Me.AgeTxt.Name = "AgeTxt"
        Me.AgeTxt.Size = New System.Drawing.Size(72, 40)
        Me.AgeTxt.TabIndex = 34
        '
        'MetricRBtn
        '
        Me.MetricRBtn.AutoSize = True
        Me.MetricRBtn.Location = New System.Drawing.Point(455, 65)
        Me.MetricRBtn.Name = "MetricRBtn"
        Me.MetricRBtn.Size = New System.Drawing.Size(73, 24)
        Me.MetricRBtn.TabIndex = 42
        Me.MetricRBtn.Text = "Open"
        Me.MetricRBtn.UseVisualStyleBackColor = True
        '
        'HeightTxt
        '
        Me.HeightTxt.Location = New System.Drawing.Point(218, 154)
        Me.HeightTxt.Multiline = True
        Me.HeightTxt.Name = "HeightTxt"
        Me.HeightTxt.Size = New System.Drawing.Size(72, 40)
        Me.HeightTxt.TabIndex = 35
        '
        'WeightTxt
        '
        Me.WeightTxt.Location = New System.Drawing.Point(218, 211)
        Me.WeightTxt.Multiline = True
        Me.WeightTxt.Name = "WeightTxt"
        Me.WeightTxt.Size = New System.Drawing.Size(72, 40)
        Me.WeightTxt.TabIndex = 36
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(296, 231)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(26, 20)
        Me.Label3.TabIndex = 37
        Me.Label3.Text = "kg"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(296, 174)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 20)
        Me.Label4.TabIndex = 38
        Me.Label4.Text = "cm"
        '
        'ClearBtn
        '
        Me.ClearBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearBtn.Location = New System.Drawing.Point(205, 358)
        Me.ClearBtn.Name = "ClearBtn"
        Me.ClearBtn.Size = New System.Drawing.Size(121, 52)
        Me.ClearBtn.TabIndex = 40
        Me.ClearBtn.Text = "Clear"
        Me.ClearBtn.UseVisualStyleBackColor = True
        '
        'CalculateBtn
        '
        Me.CalculateBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CalculateBtn.Location = New System.Drawing.Point(26, 358)
        Me.CalculateBtn.Name = "CalculateBtn"
        Me.CalculateBtn.Size = New System.Drawing.Size(121, 52)
        Me.CalculateBtn.TabIndex = 39
        Me.CalculateBtn.Text = "Calculate"
        Me.CalculateBtn.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.Label30)
        Me.TabPage2.Controls.Add(Me.BMITextBox1)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.ResultTxt1)
        Me.TabPage2.Controls.Add(Me.CloseRBtn1)
        Me.TabPage2.Controls.Add(Me.WeightUnitLbl1)
        Me.TabPage2.Controls.Add(Me.HeightUnitLbl1)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.AgeTxt1)
        Me.TabPage2.Controls.Add(Me.HeightTxt1)
        Me.TabPage2.Controls.Add(Me.ImperialRBtn1)
        Me.TabPage2.Controls.Add(Me.WeightTxt1)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.ClearBtn1)
        Me.TabPage2.Controls.Add(Me.CalculateBtn1)
        Me.TabPage2.ForeColor = System.Drawing.Color.Black
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(663, 473)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "IMPERIAL  BMI CALCULATOR "
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(20, 33)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(381, 32)
        Me.Label30.TabIndex = 51
        Me.Label30.Text = "Body Mass Index: FEMALE"
        '
        'BMITextBox1
        '
        Me.BMITextBox1.Location = New System.Drawing.Point(414, 271)
        Me.BMITextBox1.Multiline = True
        Me.BMITextBox1.Name = "BMITextBox1"
        Me.BMITextBox1.Size = New System.Drawing.Size(167, 40)
        Me.BMITextBox1.TabIndex = 49
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(22, 291)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 20)
        Me.Label5.TabIndex = 48
        Me.Label5.Text = "Result"
        '
        'ResultTxt1
        '
        Me.ResultTxt1.Location = New System.Drawing.Point(218, 271)
        Me.ResultTxt1.Multiline = True
        Me.ResultTxt1.Name = "ResultTxt1"
        Me.ResultTxt1.Size = New System.Drawing.Size(167, 40)
        Me.ResultTxt1.TabIndex = 47
        '
        'CloseRBtn1
        '
        Me.CloseRBtn1.AutoSize = True
        Me.CloseRBtn1.Checked = True
        Me.CloseRBtn1.Location = New System.Drawing.Point(455, 122)
        Me.CloseRBtn1.Name = "CloseRBtn1"
        Me.CloseRBtn1.Size = New System.Drawing.Size(74, 24)
        Me.CloseRBtn1.TabIndex = 46
        Me.CloseRBtn1.TabStop = True
        Me.CloseRBtn1.Text = "Close"
        Me.CloseRBtn1.UseVisualStyleBackColor = True
        '
        'WeightUnitLbl1
        '
        Me.WeightUnitLbl1.AutoSize = True
        Me.WeightUnitLbl1.Location = New System.Drawing.Point(384, 358)
        Me.WeightUnitLbl1.Name = "WeightUnitLbl1"
        Me.WeightUnitLbl1.Size = New System.Drawing.Size(21, 20)
        Me.WeightUnitLbl1.TabIndex = 45
        Me.WeightUnitLbl1.Text = "..."
        '
        'HeightUnitLbl1
        '
        Me.HeightUnitLbl1.AutoSize = True
        Me.HeightUnitLbl1.Location = New System.Drawing.Point(384, 390)
        Me.HeightUnitLbl1.Name = "HeightUnitLbl1"
        Me.HeightUnitLbl1.Size = New System.Drawing.Size(21, 20)
        Me.HeightUnitLbl1.TabIndex = 44
        Me.HeightUnitLbl1.Text = "..."
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(22, 122)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 20)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "AGE"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(22, 174)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(152, 20)
        Me.Label12.TabIndex = 32
        Me.Label12.Text = "HEIGHT (E.G. 183):"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(22, 231)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(142, 20)
        Me.Label13.TabIndex = 33
        Me.Label13.Text = "WEIGHT (E.G 63):"
        '
        'AgeTxt1
        '
        Me.AgeTxt1.Location = New System.Drawing.Point(218, 102)
        Me.AgeTxt1.Multiline = True
        Me.AgeTxt1.Name = "AgeTxt1"
        Me.AgeTxt1.Size = New System.Drawing.Size(72, 40)
        Me.AgeTxt1.TabIndex = 34
        '
        'HeightTxt1
        '
        Me.HeightTxt1.Location = New System.Drawing.Point(218, 154)
        Me.HeightTxt1.Multiline = True
        Me.HeightTxt1.Name = "HeightTxt1"
        Me.HeightTxt1.Size = New System.Drawing.Size(72, 40)
        Me.HeightTxt1.TabIndex = 35
        '
        'ImperialRBtn1
        '
        Me.ImperialRBtn1.AutoSize = True
        Me.ImperialRBtn1.Location = New System.Drawing.Point(455, 65)
        Me.ImperialRBtn1.Name = "ImperialRBtn1"
        Me.ImperialRBtn1.Size = New System.Drawing.Size(73, 24)
        Me.ImperialRBtn1.TabIndex = 41
        Me.ImperialRBtn1.Text = "Open"
        Me.ImperialRBtn1.UseVisualStyleBackColor = True
        '
        'WeightTxt1
        '
        Me.WeightTxt1.Location = New System.Drawing.Point(218, 211)
        Me.WeightTxt1.Multiline = True
        Me.WeightTxt1.Name = "WeightTxt1"
        Me.WeightTxt1.Size = New System.Drawing.Size(72, 40)
        Me.WeightTxt1.TabIndex = 36
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(296, 231)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(26, 20)
        Me.Label14.TabIndex = 37
        Me.Label14.Text = "kg"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(296, 174)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(30, 20)
        Me.Label15.TabIndex = 38
        Me.Label15.Text = "cm"
        '
        'ClearBtn1
        '
        Me.ClearBtn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearBtn1.Location = New System.Drawing.Point(205, 358)
        Me.ClearBtn1.Name = "ClearBtn1"
        Me.ClearBtn1.Size = New System.Drawing.Size(121, 52)
        Me.ClearBtn1.TabIndex = 40
        Me.ClearBtn1.Text = "Clear"
        Me.ClearBtn1.UseVisualStyleBackColor = True
        '
        'CalculateBtn1
        '
        Me.CalculateBtn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CalculateBtn1.Location = New System.Drawing.Point(26, 358)
        Me.CalculateBtn1.Name = "CalculateBtn1"
        Me.CalculateBtn1.Size = New System.Drawing.Size(121, 52)
        Me.CalculateBtn1.TabIndex = 39
        Me.CalculateBtn1.Text = "Calculate"
        Me.CalculateBtn1.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(133, 36)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(857, 59)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Body Mass Index Analyzer System"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BMIAnalysisBtn)
        Me.GroupBox1.Controls.Add(Me.BMRAnalysisBtn)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Button5)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(760, 128)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(242, 456)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "SYSTEM MENU"
        '
        'BMIAnalysisBtn
        '
        Me.BMIAnalysisBtn.BackColor = System.Drawing.Color.OldLace
        Me.BMIAnalysisBtn.ForeColor = System.Drawing.Color.Black
        Me.BMIAnalysisBtn.Location = New System.Drawing.Point(36, 118)
        Me.BMIAnalysisBtn.Name = "BMIAnalysisBtn"
        Me.BMIAnalysisBtn.Size = New System.Drawing.Size(154, 68)
        Me.BMIAnalysisBtn.TabIndex = 18
        Me.BMIAnalysisBtn.Text = "B.M.I Analysis"
        Me.BMIAnalysisBtn.UseVisualStyleBackColor = False
        '
        'BMRAnalysisBtn
        '
        Me.BMRAnalysisBtn.BackColor = System.Drawing.Color.Gold
        Me.BMRAnalysisBtn.ForeColor = System.Drawing.Color.Black
        Me.BMRAnalysisBtn.Location = New System.Drawing.Point(36, 36)
        Me.BMRAnalysisBtn.Name = "BMRAnalysisBtn"
        Me.BMRAnalysisBtn.Size = New System.Drawing.Size(154, 68)
        Me.BMRAnalysisBtn.TabIndex = 17
        Me.BMRAnalysisBtn.Text = "B.M.R Analysis"
        Me.BMRAnalysisBtn.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.OldLace
        Me.Button1.ForeColor = System.Drawing.Color.Black
        Me.Button1.Location = New System.Drawing.Point(36, 374)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(154, 68)
        Me.Button1.TabIndex = 16
        Me.Button1.Text = "Help"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.OldLace
        Me.Button5.ForeColor = System.Drawing.Color.Black
        Me.Button5.Location = New System.Drawing.Point(36, 290)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(154, 68)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = "FAQ"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BMI)
        Me.Panel1.Controls.Add(Me.BMR)
        Me.Panel1.Location = New System.Drawing.Point(32, 128)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(722, 525)
        Me.Panel1.TabIndex = 27
        '
        'BMR
        '
        Me.BMR.Controls.Add(Me.TabPage3)
        Me.BMR.Controls.Add(Me.TabPage4)
        Me.BMR.Location = New System.Drawing.Point(0, 0)
        Me.BMR.Name = "BMR"
        Me.BMR.SelectedIndex = 0
        Me.BMR.Size = New System.Drawing.Size(671, 506)
        Me.BMR.TabIndex = 24
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Gold
        Me.TabPage3.Controls.Add(Me.Label38)
        Me.TabPage3.Controls.Add(Me.Label39)
        Me.TabPage3.Controls.Add(Me.CR)
        Me.TabPage3.Controls.Add(Me.Label37)
        Me.TabPage3.Controls.Add(Me.Label36)
        Me.TabPage3.Controls.Add(Me.BMRTextBox)
        Me.TabPage3.Controls.Add(Me.RadioBtn5)
        Me.TabPage3.Controls.Add(Me.RadioBtn4)
        Me.TabPage3.Controls.Add(Me.RadioBtn3)
        Me.TabPage3.Controls.Add(Me.RadioBtn1)
        Me.TabPage3.Controls.Add(Me.RadioBtn2)
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.Label19)
        Me.TabPage3.Controls.Add(Me.Label20)
        Me.TabPage3.Controls.Add(Me.Label21)
        Me.TabPage3.Controls.Add(Me.Label22)
        Me.TabPage3.Controls.Add(Me.AgeBmrTxt)
        Me.TabPage3.Controls.Add(Me.HeightBmrTxt)
        Me.TabPage3.Controls.Add(Me.WeightBmrTxt)
        Me.TabPage3.Controls.Add(Me.Label32)
        Me.TabPage3.Controls.Add(Me.Label33)
        Me.TabPage3.Controls.Add(Me.btnCalculateBMRClear)
        Me.TabPage3.Controls.Add(Me.btnCalculateBMR)
        Me.TabPage3.ForeColor = System.Drawing.Color.Black
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(663, 473)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "METRIC BMR (MALE)"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Red
        Me.Label38.Location = New System.Drawing.Point(175, 98)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(138, 20)
        Me.Label38.TabIndex = 102
        Me.Label38.Text = "Calories per day"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Red
        Me.Label39.Location = New System.Drawing.Point(32, 66)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(152, 20)
        Me.Label39.TabIndex = 101
        Me.Label39.Text = "Required Calories"
        '
        'CR
        '
        Me.CR.BackColor = System.Drawing.Color.Red
        Me.CR.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CR.ForeColor = System.Drawing.SystemColors.Window
        Me.CR.Location = New System.Drawing.Point(33, 89)
        Me.CR.Multiline = True
        Me.CR.Name = "CR"
        Me.CR.Size = New System.Drawing.Size(132, 40)
        Me.CR.TabIndex = 100
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Blue
        Me.Label37.Location = New System.Drawing.Point(430, 425)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(138, 20)
        Me.Label37.TabIndex = 99
        Me.Label37.Text = "Calories per day"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Blue
        Me.Label36.Location = New System.Drawing.Point(287, 393)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(128, 20)
        Me.Label36.TabIndex = 98
        Me.Label36.Text = "BRM RESULT:"
        '
        'BMRTextBox
        '
        Me.BMRTextBox.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.BMRTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BMRTextBox.ForeColor = System.Drawing.SystemColors.Window
        Me.BMRTextBox.Location = New System.Drawing.Point(288, 416)
        Me.BMRTextBox.Multiline = True
        Me.BMRTextBox.Name = "BMRTextBox"
        Me.BMRTextBox.Size = New System.Drawing.Size(132, 40)
        Me.BMRTextBox.TabIndex = 97
        '
        'RadioBtn5
        '
        Me.RadioBtn5.AutoSize = True
        Me.RadioBtn5.Location = New System.Drawing.Point(44, 355)
        Me.RadioBtn5.Name = "RadioBtn5"
        Me.RadioBtn5.Size = New System.Drawing.Size(591, 24)
        Me.RadioBtn5.TabIndex = 93
        Me.RadioBtn5.Text = "I am super active (very hard exercise or sports and a physical job or 2x training" & _
            ")  "
        Me.RadioBtn5.UseVisualStyleBackColor = True
        '
        'RadioBtn4
        '
        Me.RadioBtn4.AutoSize = True
        Me.RadioBtn4.Location = New System.Drawing.Point(44, 309)
        Me.RadioBtn4.Name = "RadioBtn4"
        Me.RadioBtn4.Size = New System.Drawing.Size(452, 24)
        Me.RadioBtn4.TabIndex = 92
        Me.RadioBtn4.Text = "I am very active (hard exercise or sports 6 -7 days per week)"
        Me.RadioBtn4.UseVisualStyleBackColor = True
        '
        'RadioBtn3
        '
        Me.RadioBtn3.AutoSize = True
        Me.RadioBtn3.Location = New System.Drawing.Point(44, 270)
        Me.RadioBtn3.Name = "RadioBtn3"
        Me.RadioBtn3.Size = New System.Drawing.Size(533, 24)
        Me.RadioBtn3.TabIndex = 91
        Me.RadioBtn3.Text = "I am moderately active (moderate exercise or sports 3- 5 days per week"
        Me.RadioBtn3.UseVisualStyleBackColor = True
        '
        'RadioBtn1
        '
        Me.RadioBtn1.AutoSize = True
        Me.RadioBtn1.BackColor = System.Drawing.Color.Transparent
        Me.RadioBtn1.Checked = True
        Me.RadioBtn1.Location = New System.Drawing.Point(43, 180)
        Me.RadioBtn1.Name = "RadioBtn1"
        Me.RadioBtn1.Size = New System.Drawing.Size(283, 24)
        Me.RadioBtn1.TabIndex = 90
        Me.RadioBtn1.TabStop = True
        Me.RadioBtn1.Text = "I am sedentary (little or no exercise)"
        Me.RadioBtn1.UseVisualStyleBackColor = False
        '
        'RadioBtn2
        '
        Me.RadioBtn2.AutoSize = True
        Me.RadioBtn2.Location = New System.Drawing.Point(44, 225)
        Me.RadioBtn2.Name = "RadioBtn2"
        Me.RadioBtn2.Size = New System.Drawing.Size(460, 24)
        Me.RadioBtn2.TabIndex = 86
        Me.RadioBtn2.Text = "I am lightly active (light exercise or sports 1 -3 days per week)"
        Me.RadioBtn2.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(40, 152)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(205, 20)
        Me.Label6.TabIndex = 96
        Me.Label6.Text = "Select your activity level "
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label19.Location = New System.Drawing.Point(32, 30)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(253, 29)
        Me.Label19.TabIndex = 75
        Me.Label19.Text = "MALE: METRIC BRM"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(485, 128)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(47, 20)
        Me.Label20.TabIndex = 76
        Me.Label20.Text = "AGE"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(362, 18)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(170, 20)
        Me.Label21.TabIndex = 77
        Me.Label21.Text = "HEIGHT (E.G. 183):"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(374, 76)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(158, 20)
        Me.Label22.TabIndex = 78
        Me.Label22.Text = "WEIGHT (E.G 63):"
        '
        'AgeBmrTxt
        '
        Me.AgeBmrTxt.Location = New System.Drawing.Point(545, 115)
        Me.AgeBmrTxt.Multiline = True
        Me.AgeBmrTxt.Name = "AgeBmrTxt"
        Me.AgeBmrTxt.Size = New System.Drawing.Size(72, 40)
        Me.AgeBmrTxt.TabIndex = 79
        '
        'HeightBmrTxt
        '
        Me.HeightBmrTxt.Location = New System.Drawing.Point(545, 6)
        Me.HeightBmrTxt.Multiline = True
        Me.HeightBmrTxt.Name = "HeightBmrTxt"
        Me.HeightBmrTxt.Size = New System.Drawing.Size(72, 40)
        Me.HeightBmrTxt.TabIndex = 80
        '
        'WeightBmrTxt
        '
        Me.WeightBmrTxt.Location = New System.Drawing.Point(545, 63)
        Me.WeightBmrTxt.Multiline = True
        Me.WeightBmrTxt.Name = "WeightBmrTxt"
        Me.WeightBmrTxt.Size = New System.Drawing.Size(72, 40)
        Me.WeightBmrTxt.TabIndex = 81
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(623, 76)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(28, 20)
        Me.Label32.TabIndex = 82
        Me.Label32.Text = "kg"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(623, 19)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(32, 20)
        Me.Label33.TabIndex = 83
        Me.Label33.Text = "cm"
        '
        'btnCalculateBMRClear
        '
        Me.btnCalculateBMRClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculateBMRClear.Location = New System.Drawing.Point(161, 403)
        Me.btnCalculateBMRClear.Name = "btnCalculateBMRClear"
        Me.btnCalculateBMRClear.Size = New System.Drawing.Size(121, 52)
        Me.btnCalculateBMRClear.TabIndex = 85
        Me.btnCalculateBMRClear.Text = "Clear"
        Me.btnCalculateBMRClear.UseVisualStyleBackColor = True
        '
        'btnCalculateBMR
        '
        Me.btnCalculateBMR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculateBMR.Location = New System.Drawing.Point(33, 403)
        Me.btnCalculateBMR.Name = "btnCalculateBMR"
        Me.btnCalculateBMR.Size = New System.Drawing.Size(121, 52)
        Me.btnCalculateBMR.TabIndex = 84
        Me.btnCalculateBMR.Text = "Calculate"
        Me.btnCalculateBMR.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.LightGreen
        Me.TabPage4.Controls.Add(Me.Label9)
        Me.TabPage4.Controls.Add(Me.Label16)
        Me.TabPage4.Controls.Add(Me.CR2)
        Me.TabPage4.Controls.Add(Me.Label17)
        Me.TabPage4.Controls.Add(Me.Label18)
        Me.TabPage4.Controls.Add(Me.BMRTextBox2)
        Me.TabPage4.Controls.Add(Me.RadioBtn52)
        Me.TabPage4.Controls.Add(Me.RadioBtn42)
        Me.TabPage4.Controls.Add(Me.RadioBtn32)
        Me.TabPage4.Controls.Add(Me.RadioBtn12)
        Me.TabPage4.Controls.Add(Me.RadioBtn22)
        Me.TabPage4.Controls.Add(Me.Label23)
        Me.TabPage4.Controls.Add(Me.Label24)
        Me.TabPage4.Controls.Add(Me.Label25)
        Me.TabPage4.Controls.Add(Me.Label26)
        Me.TabPage4.Controls.Add(Me.Label27)
        Me.TabPage4.Controls.Add(Me.AgeBmrTxt2)
        Me.TabPage4.Controls.Add(Me.HeightBmrTxt2)
        Me.TabPage4.Controls.Add(Me.WeightBmrTxt2)
        Me.TabPage4.Controls.Add(Me.Label28)
        Me.TabPage4.Controls.Add(Me.Label29)
        Me.TabPage4.Controls.Add(Me.btnCalculateBMRClear2)
        Me.TabPage4.Controls.Add(Me.btnCalculateBMR2)
        Me.TabPage4.ForeColor = System.Drawing.Color.Black
        Me.TabPage4.Location = New System.Drawing.Point(4, 29)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(663, 473)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "METRIC BMR (FEMALE)"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(175, 98)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(138, 20)
        Me.Label9.TabIndex = 125
        Me.Label9.Text = "Calories per day"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Red
        Me.Label16.Location = New System.Drawing.Point(32, 66)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(152, 20)
        Me.Label16.TabIndex = 124
        Me.Label16.Text = "Required Calories"
        '
        'CR2
        '
        Me.CR2.BackColor = System.Drawing.Color.Red
        Me.CR2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CR2.ForeColor = System.Drawing.SystemColors.Window
        Me.CR2.Location = New System.Drawing.Point(33, 89)
        Me.CR2.Multiline = True
        Me.CR2.Name = "CR2"
        Me.CR2.Size = New System.Drawing.Size(132, 40)
        Me.CR2.TabIndex = 123
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Blue
        Me.Label17.Location = New System.Drawing.Point(430, 425)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(138, 20)
        Me.Label17.TabIndex = 122
        Me.Label17.Text = "Calories per day"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Blue
        Me.Label18.Location = New System.Drawing.Point(287, 393)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(128, 20)
        Me.Label18.TabIndex = 121
        Me.Label18.Text = "BRM RESULT:"
        '
        'BMRTextBox2
        '
        Me.BMRTextBox2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.BMRTextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BMRTextBox2.ForeColor = System.Drawing.SystemColors.Window
        Me.BMRTextBox2.Location = New System.Drawing.Point(288, 416)
        Me.BMRTextBox2.Multiline = True
        Me.BMRTextBox2.Name = "BMRTextBox2"
        Me.BMRTextBox2.Size = New System.Drawing.Size(132, 40)
        Me.BMRTextBox2.TabIndex = 120
        '
        'RadioBtn52
        '
        Me.RadioBtn52.AutoSize = True
        Me.RadioBtn52.Location = New System.Drawing.Point(44, 355)
        Me.RadioBtn52.Name = "RadioBtn52"
        Me.RadioBtn52.Size = New System.Drawing.Size(591, 24)
        Me.RadioBtn52.TabIndex = 118
        Me.RadioBtn52.Text = "I am super active (very hard exercise or sports and a physical job or 2x training" & _
            ")  "
        Me.RadioBtn52.UseVisualStyleBackColor = True
        '
        'RadioBtn42
        '
        Me.RadioBtn42.AutoSize = True
        Me.RadioBtn42.Location = New System.Drawing.Point(44, 309)
        Me.RadioBtn42.Name = "RadioBtn42"
        Me.RadioBtn42.Size = New System.Drawing.Size(452, 24)
        Me.RadioBtn42.TabIndex = 117
        Me.RadioBtn42.Text = "I am very active (hard exercise or sports 6 -7 days per week)"
        Me.RadioBtn42.UseVisualStyleBackColor = True
        '
        'RadioBtn32
        '
        Me.RadioBtn32.AutoSize = True
        Me.RadioBtn32.Location = New System.Drawing.Point(44, 270)
        Me.RadioBtn32.Name = "RadioBtn32"
        Me.RadioBtn32.Size = New System.Drawing.Size(533, 24)
        Me.RadioBtn32.TabIndex = 116
        Me.RadioBtn32.Text = "I am moderately active (moderate exercise or sports 3- 5 days per week"
        Me.RadioBtn32.UseVisualStyleBackColor = True
        '
        'RadioBtn12
        '
        Me.RadioBtn12.AutoSize = True
        Me.RadioBtn12.BackColor = System.Drawing.Color.Transparent
        Me.RadioBtn12.Checked = True
        Me.RadioBtn12.Location = New System.Drawing.Point(43, 180)
        Me.RadioBtn12.Name = "RadioBtn12"
        Me.RadioBtn12.Size = New System.Drawing.Size(283, 24)
        Me.RadioBtn12.TabIndex = 115
        Me.RadioBtn12.TabStop = True
        Me.RadioBtn12.Text = "I am sedentary (little or no exercise)"
        Me.RadioBtn12.UseVisualStyleBackColor = False
        '
        'RadioBtn22
        '
        Me.RadioBtn22.AutoSize = True
        Me.RadioBtn22.Location = New System.Drawing.Point(44, 225)
        Me.RadioBtn22.Name = "RadioBtn22"
        Me.RadioBtn22.Size = New System.Drawing.Size(460, 24)
        Me.RadioBtn22.TabIndex = 114
        Me.RadioBtn22.Text = "I am lightly active (light exercise or sports 1 -3 days per week)"
        Me.RadioBtn22.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(40, 152)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(205, 20)
        Me.Label23.TabIndex = 119
        Me.Label23.Text = "Select your activity level "
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label24.Location = New System.Drawing.Point(32, 30)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(281, 29)
        Me.Label24.TabIndex = 103
        Me.Label24.Text = "FEMALE: METRIC BRM"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(485, 128)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(47, 20)
        Me.Label25.TabIndex = 104
        Me.Label25.Text = "AGE"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(362, 18)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(170, 20)
        Me.Label26.TabIndex = 105
        Me.Label26.Text = "HEIGHT (E.G. 183):"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(374, 76)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(158, 20)
        Me.Label27.TabIndex = 106
        Me.Label27.Text = "WEIGHT (E.G 63):"
        '
        'AgeBmrTxt2
        '
        Me.AgeBmrTxt2.Location = New System.Drawing.Point(545, 115)
        Me.AgeBmrTxt2.Multiline = True
        Me.AgeBmrTxt2.Name = "AgeBmrTxt2"
        Me.AgeBmrTxt2.Size = New System.Drawing.Size(72, 40)
        Me.AgeBmrTxt2.TabIndex = 107
        '
        'HeightBmrTxt2
        '
        Me.HeightBmrTxt2.Location = New System.Drawing.Point(545, 6)
        Me.HeightBmrTxt2.Multiline = True
        Me.HeightBmrTxt2.Name = "HeightBmrTxt2"
        Me.HeightBmrTxt2.Size = New System.Drawing.Size(72, 40)
        Me.HeightBmrTxt2.TabIndex = 108
        '
        'WeightBmrTxt2
        '
        Me.WeightBmrTxt2.Location = New System.Drawing.Point(545, 63)
        Me.WeightBmrTxt2.Multiline = True
        Me.WeightBmrTxt2.Name = "WeightBmrTxt2"
        Me.WeightBmrTxt2.Size = New System.Drawing.Size(72, 40)
        Me.WeightBmrTxt2.TabIndex = 109
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(623, 76)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(28, 20)
        Me.Label28.TabIndex = 110
        Me.Label28.Text = "kg"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(623, 19)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(32, 20)
        Me.Label29.TabIndex = 111
        Me.Label29.Text = "cm"
        '
        'btnCalculateBMRClear2
        '
        Me.btnCalculateBMRClear2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculateBMRClear2.Location = New System.Drawing.Point(161, 403)
        Me.btnCalculateBMRClear2.Name = "btnCalculateBMRClear2"
        Me.btnCalculateBMRClear2.Size = New System.Drawing.Size(121, 52)
        Me.btnCalculateBMRClear2.TabIndex = 113
        Me.btnCalculateBMRClear2.Text = "Clear"
        Me.btnCalculateBMRClear2.UseVisualStyleBackColor = True
        '
        'btnCalculateBMR2
        '
        Me.btnCalculateBMR2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculateBMR2.Location = New System.Drawing.Point(33, 403)
        Me.btnCalculateBMR2.Name = "btnCalculateBMR2"
        Me.btnCalculateBMR2.Size = New System.Drawing.Size(121, 52)
        Me.btnCalculateBMR2.TabIndex = 112
        Me.btnCalculateBMR2.Text = "Calculate"
        Me.btnCalculateBMR2.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.EXPERT_SYSTEM_FOR_HUMAN_NUTRITION_ANALYSIS.My.Resources.Resources.bmi1
        Me.PictureBox1.Location = New System.Drawing.Point(-1, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(115, 96)
        Me.PictureBox1.TabIndex = 26
        Me.PictureBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1027, 665)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.ExitBtn)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.Text = "EXPERT SYSTEM FOR HUMAN NUTRITION ANALYSIS"
        Me.BMI.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.BMR.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ExitBtn As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents BMI As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents BMITextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents ResultTxt As System.Windows.Forms.TextBox
    Friend WithEvents CloseRBtn As System.Windows.Forms.RadioButton
    Friend WithEvents WeightUnitLbl As System.Windows.Forms.Label
    Friend WithEvents HeightUnitLbl As System.Windows.Forms.Label
    Friend WithEvents lblUserType As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents AgeTxt As System.Windows.Forms.TextBox
    Friend WithEvents MetricRBtn As System.Windows.Forms.RadioButton
    Friend WithEvents HeightTxt As System.Windows.Forms.TextBox
    Friend WithEvents WeightTxt As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ClearBtn As System.Windows.Forms.Button
    Friend WithEvents CalculateBtn As System.Windows.Forms.Button
    Friend WithEvents BMITextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ResultTxt1 As System.Windows.Forms.TextBox
    Friend WithEvents CloseRBtn1 As System.Windows.Forms.RadioButton
    Friend WithEvents WeightUnitLbl1 As System.Windows.Forms.Label
    Friend WithEvents HeightUnitLbl1 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents AgeTxt1 As System.Windows.Forms.TextBox
    Friend WithEvents HeightTxt1 As System.Windows.Forms.TextBox
    Friend WithEvents ImperialRBtn1 As System.Windows.Forms.RadioButton
    Friend WithEvents WeightTxt1 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents ClearBtn1 As System.Windows.Forms.Button
    Friend WithEvents CalculateBtn1 As System.Windows.Forms.Button
    Friend WithEvents BMIAnalysisBtn As System.Windows.Forms.Button
    Friend WithEvents BMRAnalysisBtn As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents BMR As System.Windows.Forms.TabControl
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents RadioBtn5 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioBtn4 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioBtn3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioBtn1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioBtn2 As System.Windows.Forms.RadioButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents AgeBmrTxt As System.Windows.Forms.TextBox
    Friend WithEvents HeightBmrTxt As System.Windows.Forms.TextBox
    Friend WithEvents WeightBmrTxt As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents btnCalculateBMRClear As System.Windows.Forms.Button
    Friend WithEvents btnCalculateBMR As System.Windows.Forms.Button
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents BMRTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents CR As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents CR2 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents BMRTextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents RadioBtn52 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioBtn42 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioBtn32 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioBtn12 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioBtn22 As System.Windows.Forms.RadioButton
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents AgeBmrTxt2 As System.Windows.Forms.TextBox
    Friend WithEvents HeightBmrTxt2 As System.Windows.Forms.TextBox
    Friend WithEvents WeightBmrTxt2 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents btnCalculateBMRClear2 As System.Windows.Forms.Button
    Friend WithEvents btnCalculateBMR2 As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
End Class
